package com.example.project;

import static android.app.PendingIntent.getActivity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.Date;

public class AlarmSet extends AppCompatActivity {
    private final int PICK_AUDIO = 1;

    Uri AudioUri;
    String sel_act;
    int State = 1;
    DBHandlr dbHandlr;
    TextView state;
    static int i=0;
    SharedPreferences prf;


    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    AlarmStore alarmStore = new AlarmStore();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm_set);
        dbHandlr = new DBHandlr(AlarmSet.this);
        Button btn_set = findViewById(R.id.set_alarm);
        TimePicker tp = findViewById(R.id.dp1);
        EditText AlarmName = findViewById(R.id.Alarm_name);
        state = findViewById(R.id.state);
        RadioGroup act = findViewById(R.id.act);
        Button back=findViewById(R.id.btn5);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(AlarmSet.this,Dash.class);
                startActivity(i);
            }
        });
        btn_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                cal.set(cal.get(Calendar.YEAR),
                        cal.get(Calendar.MONTH),
                        cal.get(Calendar.DAY_OF_MONTH),
                        tp.getHour(),
                        tp.getMinute(),0);

                long t1 = cal.getTimeInMillis();
                String t1_str=String.valueOf(t1);
                String Alarm_name_str = sel_act;
                //dbHandlr.addNewAlarm(Alarm_name_str,t1str,State,sel_act);

                Toast.makeText(AlarmSet.this, "Alarm has been added.", Toast.LENGTH_SHORT).show();
                addDatatoFirebase(Alarm_name_str, t1, 1, sel_act);
                i++;
                Intent intent = new Intent(AlarmSet.this, Dash.class);
                startActivity(intent);
            }
        });
       /*sel_tone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent audio = new Intent();
                audio.setType("audio/*");
                audio.setAction(Intent.ACTION_OPEN_DOCUMENT);
                startActivityForResult(Intent.createChooser(audio, "Select Audio"), PICK_AUDIO);

            }
        });*/
        act.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                sel_act = findViewById(checkedId).getTag().toString();
            }
        });

    }


    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_AUDIO && resultCode == RESULT_OK) {
            // Audio is Picked in format of URI
            AudioUri = data.getData();
            state.setText("Selected");

        }
    }



    private void addDatatoFirebase(String name, long time, int State, String Activity) {
        prf = getSharedPreferences("user_details" ,MODE_PRIVATE);
        String uid=prf.getString("uid",null);
        DatabaseReference databaseReference = firebaseDatabase.getReference(uid);

        // below 3 lines of code is used to set
        // data in our object class.
        alarmStore.setName(name);
        alarmStore.setTime(time);
        alarmStore.setState(State);
        alarmStore.setAct(Activity);
        databaseReference.child("Alarm"+i).setValue(alarmStore);

        // we are use add value event listener method
        // which is called with database reference.
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // inside the method of on Data change we are setting
                // our object class to our database reference.
                // data base reference will sends data to firebase.
              //  databaseReference.child("Alarm"+i).setValue(alarmStore);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // if the data is not added or it is cancelled then
                // we are displaying a failure toast message.

            }
        });
    }
}
