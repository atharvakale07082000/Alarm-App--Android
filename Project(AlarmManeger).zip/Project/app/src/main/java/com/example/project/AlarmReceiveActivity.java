package com.example.project;

import static android.content.Context.MODE_PRIVATE;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class AlarmReceiveActivity extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prf = context.getSharedPreferences("user_details", MODE_PRIVATE);
        if(prf.contains("tune") ) {
            String s=prf.getString("tune",null);
            switch (s){
                case "AlarmClockLaud":
                {
                    MyMediaPlayer.getMediaPlayerInstance().playAudioFile(context.getApplicationContext(),
                           R.raw.alarmclocklaud );
                }
                break;
                case "AlarmClock":
                {
                    MyMediaPlayer.getMediaPlayerInstance().playAudioFile(context.getApplicationContext(),
                          R.raw.alarmclock  );
                }
                break;
                case "AlarmChickenAlarm":
                {
                    MyMediaPlayer.getMediaPlayerInstance().playAudioFile(context.getApplicationContext(),
                           R.raw.alarmchickenalarm );;
                }
                break;
                case "MelodyAlarmClock":
                {
                    MyMediaPlayer.getMediaPlayerInstance().playAudioFile(context.getApplicationContext(),
                          R.raw.melodyalarmclock  );
                }
                break;
                case "Morning-Instrumental":
                {
                    MyMediaPlayer.getMediaPlayerInstance().playAudioFile(context.getApplicationContext(),
                            R.raw.morninginstrumental);
                }
                break;
                case "VivoMorningAlarm":
                {
                    MyMediaPlayer.getMediaPlayerInstance().playAudioFile(context.getApplicationContext(),
                           R.raw.vivomorningalarm );                }
                break;
        }


        }else {

            MyMediaPlayer.getMediaPlayerInstance().playAudioFile2(context,
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
        }

       // Uri AudioUri= Uri.parse(intent.getStringExtra("intent"));
       /* MediaPlayer mediaPlayer = MediaPlayer.create(context, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
        mediaPlayer.setScreenOnWhilePlaying(true);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);*/
        //notification code written here

       //MyMediaPlayer.getMediaPlayerInstance().playAudioFile(context, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));


        NotificationCompat.Builder nt= new NotificationCompat.Builder(context,"123");
        nt.setContentTitle("ALARM");
        nt.setSmallIcon(R.drawable.google);
        nt.setContentText("Its time to start your activity");
        nt.setAutoCancel(true);
        nt.setDefaults(NotificationCompat.DEFAULT_ALL);
        nt.setPriority(NotificationCompat.PRIORITY_HIGH);
        Toast.makeText(context,"Your Alarm is Running",Toast.LENGTH_LONG).show();

        NotificationManagerCompat ntr=NotificationManagerCompat.from(context);
        ntr.notify(1234,nt.build());

        Intent stop=new Intent(context.getApplicationContext(),AlarmStop.class);
        stop.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(stop);
    }
}