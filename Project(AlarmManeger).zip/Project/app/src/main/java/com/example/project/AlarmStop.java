package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AlarmStop extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm_stop);
        TextView time=findViewById(R.id.t1);
        FloatingActionButton stop = findViewById(R.id.btnstop);
        FloatingActionButton snooze = findViewById(R.id.fab2);
        Date currentTime = Calendar.getInstance().getTime();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm a");
        time.setText(simpleDateFormat.format(currentTime));
       stop.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Alarm_cancel();
               finish();
           }
       });

     snooze.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             Alarm_snooze();
             finish();
         }
     });
    }

    private void Alarm_cancel() {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(AlarmStop.this, AlarmReceiveActivity.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, 0);
        alarmManager.cancel(pendingIntent);
        pendingIntent.cancel();
        MyMediaPlayer.getMediaPlayerInstance().stopAudioFile();
        Toast.makeText(this, "Your Alarm is Stoped", Toast.LENGTH_LONG).show();


    }

    private void Alarm_snooze() {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(AlarmStop.this, AlarmReceiveActivity.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, 0);
        alarmManager.cancel(pendingIntent);
        pendingIntent.cancel();
        MyMediaPlayer.getMediaPlayerInstance().stopAudioFile();
        MyService mp = new MyService();
        long t1 = System.currentTimeMillis();
        Alarm_set(t1 + 60000);
    }

    private void Alarm_set(long timeInMillis) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(AlarmStop.this, AlarmReceiveActivity.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, 0);
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);

    }
}