package com.example.project;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class AlarmActivity extends AppCompatActivity implements View.OnClickListener {
    private TimePicker tp;
    private Button btn_set,btn_cancel;
    Uri AudioUri;
    TextView select_Audio;
    EditText Alarm_name;
    long t1;
    int State=1;

    private final int PICK_AUDIO = 1;
    DBHandlr dbHandlr;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);
        btn_set = findViewById(R.id.set_alarm);
        tp = findViewById(R.id.time);
        btn_cancel=findViewById(R.id.cancel_alarm);
        select_Audio=findViewById(R.id.select_audio);
        Alarm_name= findViewById(R.id.Alarm_name);

        Button btnsnooze = (Button)findViewById(R.id.snooze);
        btn_set.setOnClickListener(this);
        dbHandlr = new DBHandlr(AlarmActivity.this);

        //creating notification channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("123", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }


        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Alarm_cancel();

            }

        });


        btnsnooze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Alarm_snooze();
            }
        });


        select_Audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent audio = new Intent();
                audio.setType("audio/*");
                audio.setAction(Intent.ACTION_OPEN_DOCUMENT);
                startActivityForResult(Intent.createChooser(audio, "Select Audio"), PICK_AUDIO);

            }
        });
    }

    private void Alarm_snooze() {
        AlarmManager alarmManager=(AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent= new Intent(AlarmActivity.this, AlarmReceiveActivity.class);
        PendingIntent pendingIntent=PendingIntent.getBroadcast(this,0,intent,0);
        alarmManager.cancel(pendingIntent);
        pendingIntent.cancel();
        Alarm_set(t1+60000);
    }

    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_AUDIO && resultCode == RESULT_OK) {
            // Audio is Picked in format of URI
            AudioUri = data.getData();
            select_Audio.setText("Audio Selected");

        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onClick(View view) {
        Calendar cal= Calendar.getInstance();
        cal.set(cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH),
                tp.getHour(),
                tp.getMinute(),
                0);
        t1= cal.getTimeInMillis();


       //db insert code
      /*  String t1str = Long.toString(t1);
        String Alarm_name_str=Alarm_name.getText().toString();
        if (t1str.isEmpty() && Alarm_name_str.isEmpty()) {
            Toast.makeText(AlarmActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
            return;
        }
        dbHandlr.addNewAlarm(Alarm_name_str,t1str,State);
        Toast.makeText(AlarmActivity.this, "Course has been added.", Toast.LENGTH_SHORT).show();*/
        Alarm_set(t1);
    }


    private void Alarm_set(long timeInMillis) {
        AlarmManager alarmManager=(AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent= new Intent(AlarmActivity.this, AlarmReceiveActivity.class);
        PendingIntent pendingIntent=PendingIntent.getBroadcast(this,0,intent,0);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, timeInMillis,
                1000 * 60 * 60 *24, pendingIntent);
      /*if (AudioUri!=null)
        {
            intent.putExtra("Audio",AudioUri);
            Toast.makeText(this,"Your Alarm is Set with sound",Toast.LENGTH_LONG).show();

        }else{
          AudioUri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
          intent.putExtra("Audio",AudioUri);
          Toast.makeText(this,"Your Alarm is Set",Toast.LENGTH_LONG).show();

      }*/


    }
    private void Alarm_cancel() {
        AlarmManager alarmManager=(AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent= new Intent(AlarmActivity.this, AlarmReceiveActivity.class);

        PendingIntent pendingIntent=PendingIntent.getBroadcast(this,0,intent,0);
        alarmManager.cancel(pendingIntent);
        pendingIntent.cancel();
        Toast.makeText(this,"Your Alarm is Cancel",Toast.LENGTH_LONG).show();


    }


}