package com.example.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class AlarmListAdapter extends RecyclerView.Adapter<AlarmListAdapter.ViewHolder> {

    // variable for our array list and context
    private ArrayList<AlarmStore>alarmStoreArrayList;
    private Context context;

    // constructor
    public AlarmListAdapter(ArrayList<AlarmStore> alarmStoreArrayList, Context context) {
        this.alarmStoreArrayList = alarmStoreArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // on below line we are inflating our layout
        // file for our recycler view items.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.one_alarm, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // on below line we are setting data
        // to our views of recycler view item.
        AlarmStore store = alarmStoreArrayList.get(position);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm a");


        long t=store.getTime();
        Date date = new Date(t);
        String time = simpleDateFormat.format(date);
        holder.ac_name.setText(store.getAct());
        holder.time.setText((time));
    }

    @Override
    public int getItemCount() {
        // returning the size of our array list
        return alarmStoreArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        // creating variables for our text views.
        private TextView ac_name,time;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing our text views
            ac_name= itemView.findViewById(R.id.ac_name);
            time = itemView.findViewById(R.id.time);

        }
    }
}
