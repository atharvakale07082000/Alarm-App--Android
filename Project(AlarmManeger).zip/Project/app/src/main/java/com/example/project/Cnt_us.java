package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Cnt_us extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cnt_us);
        TextView email=findViewById(R.id.mail);
        EditText msg=findViewById(R.id.msg);
        Button submit=findViewById(R.id.btnsubmit);

        SharedPreferences prf=getSharedPreferences("user_details",MODE_PRIVATE);
        email.setText(prf.getString("email",null));
        String uid =prf.getString("uid",null);
        FirebaseDatabase firebaseDatabase=FirebaseDatabase.getInstance();
        DatabaseReference databaseReference=firebaseDatabase.getReference("cont_req");

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String m=msg.getText().toString();
                databaseReference.child(uid).child("msg").setValue(m);
                Intent intent = new Intent(Cnt_us.this, Dash.class);
                startActivity(intent);
            }
        });

    }
}