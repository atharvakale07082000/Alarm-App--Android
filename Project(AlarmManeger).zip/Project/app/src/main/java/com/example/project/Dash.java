package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;


import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;



import com.google.android.material.navigation.NavigationBarView;

public class Dash extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_dash);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        navView.setSelectedItemId(R.id.navigation_home);

        ProfileFragment thirdFragment = new ProfileFragment();
        MyHomeFrag firstFragment = new MyHomeFrag();
        ChallegesFragment secondFragment = new ChallegesFragment();
        startService(new Intent( this, MyService.class ) );
        getSupportFragmentManager().beginTransaction().replace(R.id.container, firstFragment).commit();

        navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
                                              @Override
                                              public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                                                  switch (item.getItemId()) {
                                                      case R.id.navigation_home:
                                                          getSupportFragmentManager().beginTransaction().replace(R.id.container, firstFragment).commit();
                                                          return true;

                                                      case R.id.navigation_challenges:
                                                          getSupportFragmentManager().beginTransaction().replace(R.id.container, secondFragment).commit();
                                                          return true;

                                                      case R.id.navigation_My_Profile:
                                                          getSupportFragmentManager().beginTransaction().replace(R.id.container, thirdFragment).commit();
                                                          return true;

                                                  } return false;
                                              }

                                          });


    }
}