package com.example.project;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ChallegesFragment extends Fragment {
    String uid;
    private TextView challengeTextView;
    private Button completeButton;
    private int challengeIndex = 0;
    private String[] challenges = {
            "Wake up at 6am ",
            "Exercise for 30 minutes before starting your work day for week",
            "Meditate for 10 minutes before breakfast for a month",
            "Plan out your tasks for the day before checking emails for year"
    };

    FirebaseDatabase firebaseDatabase=FirebaseDatabase.getInstance();
    DatabaseReference databaseReference=firebaseDatabase.getReference("chall_state");


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_challeges, container, false);
        SharedPreferences prf = getActivity().getSharedPreferences("user_details", MODE_PRIVATE);
        uid = prf.getString("uid", null);
        challengeTextView = view.findViewById(R.id.challenge_text_view);
        completeButton = view.findViewById(R.id.complete_button);


        updateChallenge();

        completeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveChallengeStatus();
                updateChallenge();
            }
        });

        return view;
    }

    private void updateChallenge() {
        if (challengeIndex >= challenges.length) {
            Toast.makeText(getContext(), "Congratulations, you completed all challenges!", Toast.LENGTH_SHORT).show();
            getActivity().finish();
            return;
        }
        challengeTextView.setText(challenges[challengeIndex]);
        challengeIndex++;
    }

    private void saveChallengeStatus() {
        String challengeId = "challenge_" + (challengeIndex - 1);

        databaseReference.child("uid").child(challengeId).setValue(true);
    }

}
