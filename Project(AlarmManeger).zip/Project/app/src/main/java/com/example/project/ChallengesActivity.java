package com.example.project;

import android.app.Activity;

public class ChallengesActivity extends Activity {
}
