package com.example.project;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;

public class MyMediaPlayer {

    private static MyMediaPlayer Instance;
    MediaPlayer mediaPlayer;

    static MyMediaPlayer getMediaPlayerInstance() {
        if (Instance == null) {
            return Instance = new MyMediaPlayer();
        }
        return Instance;
    }

    public void playAudioFile(Context context, int sampleAudio) {
        mediaPlayer = MediaPlayer.create(context, sampleAudio);
        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.start();
                mp.setLooping(true);
                mp.setScreenOnWhilePlaying(true);
            }
        });

    }
    public void playAudioFile2(Context context, Uri sampleAudio) {
        mediaPlayer = MediaPlayer.create(context, sampleAudio);
        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.start();
                mp.setLooping(true);
                mp.setScreenOnWhilePlaying(true);
            }
        });
    }
    public void stopAudioFile() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
    }
}