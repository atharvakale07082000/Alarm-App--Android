package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class AcDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ac_details);
        TextView result = (TextView)findViewById(R.id.resultView);
        TextView chall_comp=(TextView)findViewById(R.id.chall_comp);
        Button btnLogOut = (Button)findViewById(R.id.btnLogout);
        Spinner sel_aud=findViewById(R.id.select_audio);
        DatabaseReference challengeStatusRef = FirebaseDatabase.getInstance().getReference("chall_state").child("uid");
        FirebaseAuth mAuth=FirebaseAuth.getInstance();
        SharedPreferences prf = getSharedPreferences("user_details" ,MODE_PRIVATE);
        SharedPreferences.Editor editor = prf.edit();

        Intent intent = new Intent(AcDetails.this,Dash.class);
        result.setText(prf.getString("email" ,null));
        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SharedPreferences.Editor editor = prf.edit();
                editor.clear();
                editor.commit();
                mAuth.signOut();
                startActivity(intent);

            }
        });
        ArrayAdapter<CharSequence> adp3 = ArrayAdapter.createFromResource(this,
                R.array.aud, android.R.layout.simple_list_item_1);

        adp3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sel_aud.setAdapter(adp3);
        sel_aud.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String ss = sel_aud.getSelectedItem().toString();
                editor.putString("tune" ,ss);
                editor.commit();
                Toast.makeText(AcDetails.this, "song "+ss, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        challengeStatusRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int challengesCompleted = 0;
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    boolean isCompleted = dataSnapshot.getValue(Boolean.class);
                  //  Map<String, Object> challengeStatus = (Map<String, Object>) dataSnapshot.getValue();
                    if (isCompleted) {
                        challengesCompleted++;
                    }
                }
                // Use challengesCompleted variable to display the number of challenges completed.
                // For example:
                chall_comp.setText("Completed Challenges: " + challengesCompleted);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });

    }
}
