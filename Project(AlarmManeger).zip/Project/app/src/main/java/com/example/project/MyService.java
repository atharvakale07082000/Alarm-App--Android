package com.example.project;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyService extends Service {
    public MyService() {
    }

    HashMap<String, Long> map = new HashMap<>();
    List<AlarmStore> alarmStoreList=new ArrayList<>();


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences prf = getSharedPreferences("user_details", MODE_PRIVATE);
        String uid = prf.getString("uid", null);
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference(uid);
       // Toast.makeText(this, "a"+databaseReference, Toast.LENGTH_LONG).show();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //creating notification channel
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    CharSequence name = getString(R.string.channel_name);
                    String description = getString(R.string.channel_description);
                    int importance = NotificationManager.IMPORTANCE_HIGH;
                    NotificationChannel channel = new NotificationChannel("123", name, importance);
                    channel.setDescription(description);
                    // Register the channel with the system; you can't change the importance
                    // or other notification behaviors after this
                    NotificationManager notificationManager = getSystemService(NotificationManager.class);
                    notificationManager.createNotificationChannel(channel);
                }
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {

                    // Long AlarmTime = (Long) snapshot.child("time").getValue();
                    //String Activity = (String) snapshot.child("act").getValue();
                    AlarmStore alarm = snapshot.getValue(AlarmStore.class);
                    alarmStoreList.add(alarm);
//                  Toast.makeText(MyService.this, "time "+AlarmTime+" Act "+Activity, Toast.LENGTH_SHORT).show();
                   // map.put(Activity, AlarmTime);
                    //ArrayList<Map.Entry<String, Long>> arrayList = new ArrayList(map.entrySet());
                }

                    Alarm_set();
             //   ArrayList<Map.Entry<String, Long>> arrayList = new ArrayList(map.entrySet());
              //  arrayList.forEach((n) -> {
                 // Toast.makeText(MyService.this, ""+n, Toast.LENGTH_LONG).show();
                   // alarm(n);
                }



            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });


        return super.onStartCommand(intent, flags, startId);
    }

    private void alarm(Map.Entry<String, Long> n) {


        for (Map.Entry<String, Long> entry : map.entrySet()) {
            String key = entry.getKey();
            Long t = entry.getValue();
        Toast.makeText(MyService.this, "key "+key+"t "+t, Toast.LENGTH_SHORT).show();

            // do something with key and/or tab
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    public void Alarm_set() {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        for (AlarmStore alarm : alarmStoreList) {
            Intent intent = new Intent(getApplicationContext(), AlarmReceiveActivity.class);
            intent.putExtra("act", alarm.getAct());
            PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), alarm.getId(), intent, PendingIntent.FLAG_IMMUTABLE);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,alarm.getTime(),
                1000 * 60 * 60 * 24, pendingIntent);
    }
    }
}