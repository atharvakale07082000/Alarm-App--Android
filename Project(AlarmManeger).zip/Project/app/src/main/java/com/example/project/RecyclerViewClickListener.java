package com.example.project;

import android.view.View;

public interface RecyclerViewClickListener {

    void onClick(View view, int position);
}
