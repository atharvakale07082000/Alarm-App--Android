package com.example.project;

import static android.view.WindowManager.*;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;

public class HomeActivity extends AppCompatActivity {
    EditText t1;
    EditText t2;
    ProgressBar bar;
    FirebaseAuth mAuth;
    Button b1, b2,b3;
    private GoogleSignInClient gsn;
    SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        getWindow().setFlags(LayoutParams.FLAG_FULLSCREEN, LayoutParams.FLAG_FULLSCREEN);
        t1= (EditText) findViewById(R.id.email);
        t2= (EditText) findViewById(R.id.pass);
        b1 = (Button) findViewById(R.id.btnsignup);
        b3=(Button)findViewById(R.id.btnLogin);
        b2=(Button)findViewById(R.id.btnemailup);
        mAuth=FirebaseAuth.getInstance();
        pref = getSharedPreferences("user_details" ,MODE_PRIVATE);
        Intent intent=new Intent(HomeActivity.this,Dash.class);
        if(pref.contains("email" ) && pref.contains("uid")) {
            startActivity(intent);
        }

        GoogleSignInOptions options= new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        gsn = GoogleSignIn.getClient(this,options);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= gsn.getSignInIntent();
                startActivityForResult(intent,123);


            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(HomeActivity.this,RegisterActivity.class);
                startActivity(i);
            }
        });
        t1.setImeOptions(EditorInfo.IME_ACTION_DONE);
        t2.setImeOptions(EditorInfo.IME_ACTION_DONE);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=t1.getText().toString();
                String pass=t2.getText().toString();
                if((email!=null && email.equals(""))||(pass!=null && pass.equals("")))
                {
                    Toast.makeText(getApplicationContext(),"Fill Entries",Toast.LENGTH_LONG).show();

                }
                else {
                    mAuth.signInWithEmailAndPassword(email, pass)
                            .addOnCompleteListener(HomeActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        Intent intent = new Intent(HomeActivity.this, Dash.class);
                                        SharedPreferences.Editor editor = pref.edit();
                                        editor.putString("email", mAuth.getCurrentUser().getEmail());
                                        editor.putString("uid", mAuth.getCurrentUser().getUid());
                                        editor.commit();
                                        startActivity(intent);
                                    } else {
                                        // If sign in fails, display a message to the user.
                                        t1.setText("");
                                        t2.setText("");
                                        Toast.makeText(getApplicationContext(), "Invalid Entries", Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==123){
            Task<GoogleSignInAccount>task=GoogleSignIn.getSignedInAccountFromIntent(data);
            try{
                GoogleSignInAccount account=task.getResult(ApiException.class);
                AuthCredential credential= GoogleAuthProvider.getCredential(account.getIdToken(),null);
                mAuth.signInWithCredential(credential).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        if (task.isSuccessful()) {
                            Intent intent=new Intent(HomeActivity.this,Dash.class);
                            SharedPreferences.Editor editor = pref.edit();
                            editor.putString("email" ,mAuth.getCurrentUser().getEmail());
                            editor.putString("uid",mAuth.getCurrentUser().getUid());
                            editor.commit();
                            startActivity(intent);
                        } else {
                            // If sign in fails, display a message to the user.
                            t1.setText("");
                            t2.setText("");
                            Toast.makeText(getApplicationContext(),"Invalid Entries",Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }catch (ApiException e){
                e.printStackTrace();
            }
        }
    }




}