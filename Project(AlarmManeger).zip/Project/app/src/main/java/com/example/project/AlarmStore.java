package com.example.project;

import java.util.Date;

public class AlarmStore {

    // variables for our coursename,
    // description, tracks and duration, id.

    private int id;
    private String name;
    private long time;
    private int state;



    private String Act;
    public AlarmStore() {
    }

    // creating getter and setter methods

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getAct() {
        return Act;
    }

    public void setAct(String act) {
        Act = act;
    }

    // constructor

    public AlarmStore(int id, String name, long time, int state, String act) {
        this.id = id;
        this.name = name;
        this.time = time;
        this.state = state;
        Act = act;
    }
}
